# Design Rules

**Version**: 1.0
**Updated**: [Date]

---

## Colors

| Token | Light | Dark | Usage |
|-------|-------|------|-------|

---

## Typography

| Element | Class | Notes |
|---------|-------|-------|

---

## Spacing

| Context | Value | Notes |
|---------|-------|-------|

---

## Motion

### By Zone

| Zone | Style | Timing | Notes |
|------|-------|--------|-------|
| critical | deliberate | 800ms+ | |
| marketing | playful | - | |
| admin | snappy | <200ms | |

### Recipes

| Recipe | Zone | Parameters |
|--------|------|------------|

---

## Components

<!-- Component-specific rules -->

---

## Approvals

| Component | Approved | Date | By |
|-----------|----------|------|----|
