# Product Moodboard

**Product**: [Name]
**Created**: [Date]
**Updated**: [Date]

---

## Reference Products

### Games
<!-- What games inspire this product's feel? -->

### Apps
<!-- What apps inspire this product's feel? -->

---

## Feel Descriptors

| Context | Feel | Reference |
|---------|------|-----------|
| Transactions | | |
| Success states | | |
| Loading | | |
| Errors | | |

---

## Anti-Patterns

<!-- What patterns should we explicitly avoid? -->

---

## Key Moments

### High-Stakes Actions
<!-- How should critical actions feel? -->

### Celebrations
<!-- How should wins feel? -->

### Recovery
<!-- How should errors feel? -->
