---
name: "deploy-production"
version: "1.0.0"
description: |
  Design and deploy production infrastructure.
  IaC, CI/CD, monitoring, security hardening, operational docs.

arguments: []

agent: "deploying-infrastructure"
agent_path: "skills/deploying-infrastructure/"

context_files:
  - path: "loa-grimoire/prd.md"
    required: true
    purpose: "Product requirements for infrastructure needs"
  - path: "loa-grimoire/sdd.md"
    required: true
    purpose: "Architecture for deployment design"
  - path: "loa-grimoire/sprint.md"
    required: true
    purpose: "Sprint completion status"
  - path: "loa-grimoire/a2a/integration-context.md"
    required: false
    purpose: "Organizational context and MCP tools"

pre_flight:
  - check: "file_exists"
    path: ".loa-setup-complete"
    error: "Loa setup has not been completed. Run /setup first."

  - check: "file_exists"
    path: "loa-grimoire/prd.md"
    error: "PRD not found. Run /plan-and-analyze first."

  - check: "file_exists"
    path: "loa-grimoire/sdd.md"
    error: "SDD not found. Run /architect first."

  - check: "file_exists"
    path: "loa-grimoire/sprint.md"
    error: "Sprint plan not found. Run /sprint-plan first."

outputs:
  - path: "loa-grimoire/deployment/"
    type: "directory"
    description: "Deployment documentation and runbooks"
  - path: "loa-grimoire/a2a/deployment-report.md"
    type: "file"
    description: "Deployment report for audit"

mode:
  default: "foreground"
  allow_background: true
---

# Deploy Production

## Purpose

Design and deploy production infrastructure with security-first approach. Creates IaC, CI/CD pipelines, monitoring, and comprehensive operational documentation.

## Invocation

```
/deploy-production
/deploy-production background
```

## Agent

Launches `deploying-infrastructure` from `skills/deploying-infrastructure/`.

See: `skills/deploying-infrastructure/SKILL.md` for full workflow details.

## Prerequisites

- Setup completed (`.loa-setup-complete` exists)
- PRD, SDD, and sprint plan created
- Sprints implemented and approved
- Security audit passed (recommended)

## Workflow

1. **Project Review**: Read PRD, SDD, sprint plan, implementation reports
2. **Requirements Clarification**: Ask about cloud, scaling, security, budget
3. **Infrastructure Design**: IaC, networking, compute, data, security
4. **Implementation**: Provision resources, configure services
5. **Deployment**: Execute with zero-downtime strategies
6. **Monitoring Setup**: Observability, alerting, dashboards
7. **Documentation**: Create runbooks and operational docs
8. **Knowledge Transfer**: Handover with critical info
9. **Analytics**: Update usage metrics (THJ users only)
10. **Feedback**: Suggest `/feedback` command

## Arguments

| Argument | Description | Required |
|----------|-------------|----------|
| `background` | Run as subagent for parallel execution | No |

## Outputs

| Path | Description |
|------|-------------|
| `loa-grimoire/deployment/infrastructure.md` | Architecture overview |
| `loa-grimoire/deployment/deployment-guide.md` | How to deploy |
| `loa-grimoire/deployment/runbooks/` | Operational procedures |
| `loa-grimoire/deployment/monitoring.md` | Dashboards, alerts |
| `loa-grimoire/deployment/security.md` | Access, secrets |
| `loa-grimoire/deployment/disaster-recovery.md` | Backup, failover |
| `loa-grimoire/a2a/deployment-report.md` | Report for audit |

## Requirements Clarification

The architect will ask about:
- **Deployment Environment**: Cloud provider, regions
- **Blockchain/Crypto**: Chains, nodes, key management
- **Scale and Performance**: Traffic, data volume, SLAs
- **Security and Compliance**: SOC 2, GDPR, secrets
- **Budget and Cost**: Constraints, optimization
- **Team and Operations**: Size, on-call, tools
- **Monitoring**: Metrics, channels, retention
- **CI/CD**: Repository, branch strategy, deployment
- **Backup and DR**: RPO/RTO, frequency, failover

## Quality Standards

- Infrastructure as Code (version controlled)
- Security (defense in depth, least privilege)
- Monitoring (comprehensive before going live)
- Automation (CI/CD fully automated)
- Documentation (complete operational docs)
- Tested (staging tested, DR validated)
- Scalable (handles expected load)
- Cost-Optimized (within budget)
- Recoverable (backups tested, DR in place)

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| "Loa setup has not been completed" | Missing `.loa-setup-complete` | Run `/setup` first |
| "PRD not found" | Missing prd.md | Run `/plan-and-analyze` first |
| "SDD not found" | Missing sdd.md | Run `/architect` first |
| "Sprint plan not found" | Missing sprint.md | Run `/sprint-plan` first |

## Feedback Loop

After deployment, run `/audit-deployment` for security review:

```
/deploy-production
      ↓
[deployment-report.md created]
      ↓
/audit-deployment
      ↓
[feedback or approval]
      ↓
If issues: fix and re-run /deploy-production
If approved: Ready for production
```

## Next Step

After deployment: `/audit-deployment` for infrastructure security audit
